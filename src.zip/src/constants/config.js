// Polygon Amoy Testnet Configuration
export const NETWORK = {
  chainId:     "0x13882",       // 80002 in hex
  chainName:   "Polygon Amoy Testnet",
  rpcUrls:     ["https://rpc-amoy.polygon.technology/"],
  nativeCurrency: { name: "MATIC", symbol: "MATIC", decimals: 18 },
  blockExplorerUrls: ["https://amoy.polygonscan.com/"],
};

export const CLAUDE_API_KEY = process.env.REACT_APP_CLAUDE_API_KEY || "";

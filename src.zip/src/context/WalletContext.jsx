import { createContext, useContext } from "react";
import { useWallet } from "../hooks/useWallet";
import { useContract } from "../hooks/useContract";

const WalletContext = createContext(null);

export function WalletProvider({ children }) {
  const wallet    = useWallet();
  const contracts = useContract(wallet.signer, wallet.provider);
  return (
    <WalletContext.Provider value={{ ...wallet, ...contracts }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWalletContext() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWalletContext must be inside WalletProvider");
  return ctx;
}

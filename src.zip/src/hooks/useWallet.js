import { useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";
import { NETWORK } from "../constants/config";

export function useWallet() {
  const [account,   setAccount]   = useState(null);
  const [provider,  setProvider]  = useState(null);
  const [signer,    setSigner]    = useState(null);
  const [chainId,   setChainId]   = useState(null);
  const [error,     setError]     = useState(null);
  const [loading,   setLoading]   = useState(false);

  // ─── Connect MetaMask ────────────────────────────────────────
  const connect = useCallback(async () => {
    if (!window.ethereum) {
      setError("MetaMask not found. Please install MetaMask extension.");
      return;
    }
    try {
      setLoading(true);
      setError(null);

      // Request account access
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts"
      });

      // Switch to Polygon Amoy
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: NETWORK.chainId }],
        });
      } catch (switchErr) {
        // Chain not added yet — add it
        if (switchErr.code === 4902) {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [NETWORK],
          });
        }
      }

      const web3Provider = new ethers.BrowserProvider(window.ethereum);
      const web3Signer   = await web3Provider.getSigner();
      const network      = await web3Provider.getNetwork();

      setAccount(accounts[0]);
      setProvider(web3Provider);
      setSigner(web3Signer);
      setChainId(Number(network.chainId));
    } catch (err) {
      setError(err.message || "Connection failed");
    } finally {
      setLoading(false);
    }
  }, []);

  // ─── Disconnect ──────────────────────────────────────────────
  const disconnect = useCallback(() => {
    setAccount(null); setProvider(null);
    setSigner(null);  setChainId(null);
  }, []);

  // ─── Listen for account / chain changes ─────────────────────
  useEffect(() => {
    if (!window.ethereum) return;
    const onAccounts = (accs) => accs.length === 0 ? disconnect() : setAccount(accs[0]);
    const onChain    = (id)   => setChainId(parseInt(id, 16));
    window.ethereum.on("accountsChanged", onAccounts);
    window.ethereum.on("chainChanged",    onChain);
    return () => {
      window.ethereum.removeListener("accountsChanged", onAccounts);
      window.ethereum.removeListener("chainChanged",    onChain);
    };
  }, [disconnect]);

  const shortAddress = account
    ? `${account.substring(0, 6)}...${account.substring(account.length - 4)}`
    : null;

  const isCorrectNetwork = chainId === 80002;

  return { account, provider, signer, chainId, error, loading,
           connect, disconnect, shortAddress, isCorrectNetwork };
}

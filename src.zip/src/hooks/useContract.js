import { useMemo } from "react";
import { ethers } from "ethers";
import { ADDRESSES } from "../constants/addresses";
import SHGCrowdfundJson from '../abis/SHGCrowdfund.json';
import SoulBoundTokenJson from "../abis/SoulBoundToken.json";
import RefundGovJson from "../abis/RefundGovernance.json";

const SHGCrowdfundABI = SHGCrowdfundJson.abi;
const SoulBoundTokenABI = SoulBoundTokenJson.abi;
const RefundGovABI = RefundGovJson.abi;

export function useContract(signer, provider) {
  const crowdfund = useMemo(() => {
    const runner = signer || provider;
    if (!runner || !ADDRESSES.SHGCrowdfund) return null;
    return new ethers.Contract(ADDRESSES.SHGCrowdfund, SHGCrowdfundABI, runner);
  }, [signer, provider]);

  const sbt = useMemo(() => {
    const runner = signer || provider;
    if (!runner || !ADDRESSES.SoulBoundToken) return null;
    return new ethers.Contract(ADDRESSES.SoulBoundToken, SoulBoundTokenABI, runner);
  }, [signer, provider]);

  const governance = useMemo(() => {
    const runner = signer || provider;
    if (!runner || !ADDRESSES.RefundGovernance) return null;
    return new ethers.Contract(ADDRESSES.RefundGovernance, RefundGovABI, runner);
  }, [signer, provider]);

  return { crowdfund, sbt, governance };
}
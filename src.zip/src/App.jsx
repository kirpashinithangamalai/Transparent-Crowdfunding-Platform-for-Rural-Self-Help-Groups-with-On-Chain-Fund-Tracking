import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { WalletProvider } from "./context/WalletContext";
import Navbar       from "./components/layout/Navbar";
import Home         from "./pages/Home";
import Campaign     from "./pages/Campaign";
import Dashboard    from "./pages/Dashboard";
import DonorProfile from "./pages/DonorProfile";
import Governance   from "./pages/Governance";
import CreateCampaign from "./pages/CreateCampaign";

export default function App() {
  return (
    <WalletProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/"               element={<Home />} />
          <Route path="/campaign/:id"   element={<Campaign />} />
          <Route path="/create"         element={<CreateCampaign />} />
          <Route path="/dashboard"      element={<Dashboard />} />
          <Route path="/profile"        element={<DonorProfile />} />
          <Route path="/governance"     element={<Governance />} />
        </Routes>
      </BrowserRouter>
    </WalletProvider>
  );
}

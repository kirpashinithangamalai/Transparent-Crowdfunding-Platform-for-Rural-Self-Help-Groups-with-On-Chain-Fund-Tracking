import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { Link } from "react-router-dom";
import { useWalletContext } from "../context/WalletContext";

export default function Dashboard() {
  const { crowdfund, account, connect } = useWalletContext();
  const [myCampaigns, setMyCampaigns] = useState([]);

  useEffect(() => {
    if (!crowdfund || !account) return;
    (async () => {
      const count = await crowdfund.campaignCount();
      const list  = [];
      for (let i = 1; i <= Number(count); i++) {
        const c = await crowdfund.campaigns(i);
        if (c.shgAddress.toLowerCase() === account.toLowerCase()) {
          const ms = await crowdfund.getMilestones(i);
          list.push({ ...c, id: i, milestones: ms });
        }
      }
      setMyCampaigns(list);
    })();
  }, [crowdfund, account]);

  if (!account) return (
    <div style={s.page}>
      <div style={s.center}>
        <h1 style={s.h1}>Connect wallet to view your SHG dashboard</h1>
        <button style={s.btn} onClick={connect}>🦊 Connect MetaMask</button>
      </div>
    </div>
  );

  return (
    <div style={s.page}>
      <div style={s.eyebrow}>SHG OWNER DASHBOARD</div>
      <h1 style={s.h1}>Your <span style={{color:"#10b981"}}>Campaigns</span></h1>

      {myCampaigns.length === 0 ? (
        <div style={s.empty}>
          No campaigns yet. <Link to="/create" style={{color:"#a855f7"}}>Create your first campaign →</Link>
        </div>
      ) : myCampaigns.map(c => {
        const pct = Math.round(Number(ethers.formatEther(c.raisedAmount)) / Number(ethers.formatEther(c.goalAmount)) * 100);
        const done = c.milestones.filter(m => m.completed).length;
        return (
          <div key={c.id} style={s.card}>
            <div style={s.cardTop}>
              <div>
                <div style={s.title}>{c.title}</div>
                <div style={s.meta}>Impact Score: <strong style={{color:"#f59e0b"}}>{Number(c.impactScore)}/100</strong></div>
              </div>
              <Link to={`/campaign/${c.id}`} style={s.viewBtn}>View & Submit Proof →</Link>
            </div>
            <div style={s.statsRow}>
              <div style={s.stat}><strong style={{color:"#10b981"}}>{Number(ethers.formatEther(c.raisedAmount)).toFixed(2)}</strong><div style={s.statL}>MATIC RAISED</div></div>
              <div style={s.stat}><strong style={{color:"#a855f7"}}>{pct}%</strong><div style={s.statL}>FUNDED</div></div>
              <div style={s.stat}><strong style={{color:"#06b6d4"}}>{done}/{c.milestones.length}</strong><div style={s.statL}>MILESTONES</div></div>
              <div style={s.stat}><strong style={{color:"#f59e0b"}}>{Number(c.donorCount)}</strong><div style={s.statL}>DONORS</div></div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

const s = {
  page:    { paddingTop:100, maxWidth:1000, margin:"0 auto", padding:"100px 2rem 4rem" },
  center:  { textAlign:"center", padding:"4rem 0" },
  eyebrow: { fontSize:"0.62rem", letterSpacing:"0.25em", color:"#10b981", marginBottom:8 },
  h1:      { color:"#fff", fontWeight:900, fontSize:"clamp(1.8rem,3vw,2.8rem)", marginBottom:"2rem" },
  empty:   { color:"#666", fontSize:"0.9rem" },
  card:    { background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"1.5rem", marginBottom:"1.2rem" },
  cardTop: { display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"1.2rem" },
  title:   { color:"#fff", fontWeight:800, fontSize:"1rem", marginBottom:4 },
  meta:    { color:"rgba(255,255,255,0.5)", fontSize:"0.72rem" },
  viewBtn: { background:"linear-gradient(135deg,#7c3aed,#ec4899)", color:"#fff", textDecoration:"none", padding:"8px 16px", borderRadius:8, fontWeight:700, fontSize:"0.72rem", whiteSpace:"nowrap" },
  statsRow:{ display:"flex", gap:"2rem" },
  stat:    { textAlign:"center" },
  statL:   { fontSize:"0.55rem", letterSpacing:"0.1em", color:"rgba(255,255,255,0.35)", marginTop:2 },
  btn:     { background:"linear-gradient(135deg,#7c3aed,#ec4899)", color:"#fff", border:"none", borderRadius:10, padding:"12px 28px", fontWeight:800, fontSize:"0.85rem", cursor:"pointer", marginTop:16 },
};

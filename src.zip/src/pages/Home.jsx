import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { Link } from "react-router-dom";
import { useWalletContext } from "../context/WalletContext";

const EXAMPLE_CAMPAIGNS = [
  {
    id: 101,
    shgName: "Muthal Mariyamman SHG",
    title: "Tailoring Unit for Rural Women",
    location: "Theni, Tamil Nadu",
    goalAmount: BigInt("10000000000000000"),
    raisedAmount: BigInt("5000000000000000"),
    donorCount: BigInt(12),
    impactScore: BigInt(65),
    active: true, completed: false, vouchedBy: false,
    milestones: [
      { description: "Buy sewing machines", fundAmount: BigInt("5000000000000000"), completed: true,  proofIPFSHash: "" },
      { description: "Training & setup",    fundAmount: BigInt("5000000000000000"), completed: false, proofIPFSHash: "" },
    ],
    isExample: true,
  },
  {
    id: 102,
    shgName: "Kaveri Organic Farmers SHG",
    title: "Organic Vegetable Farming Expansion",
    location: "Trichy, Tamil Nadu",
    goalAmount: BigInt("50000000000000000"),
    raisedAmount: BigInt("40000000000000000"),
    donorCount: BigInt(34),
    impactScore: BigInt(82),
    active: true, completed: false, vouchedBy: true,
    milestones: [
      { description: "Buy seeds & fertilizers", fundAmount: BigInt("15000000000000000"), completed: true,  proofIPFSHash: "" },
      { description: "Setup irrigation system",  fundAmount: BigInt("20000000000000000"), completed: true,  proofIPFSHash: "" },
      { description: "First harvest & market",   fundAmount: BigInt("15000000000000000"), completed: false, proofIPFSHash: "" },
    ],
    isExample: true,
  },
  {
    id: 103,
    shgName: "Vellai Thamarai Women SHG",
    title: "Handloom Weaving Micro-Enterprise",
    location: "Madurai, Tamil Nadu",
    goalAmount: BigInt("30000000000000000"),
    raisedAmount: BigInt("9000000000000000"),
    donorCount: BigInt(7),
    impactScore: BigInt(50),
    active: true, completed: false, vouchedBy: false,
    milestones: [
      { description: "Purchase handlooms",      fundAmount: BigInt("15000000000000000"), completed: false, proofIPFSHash: "" },
      { description: "Weaving skills training", fundAmount: BigInt("10000000000000000"), completed: false, proofIPFSHash: "" },
      { description: "Market & sell products",  fundAmount: BigInt("5000000000000000"),  completed: false, proofIPFSHash: "" },
    ],
    isExample: true,
  },
  {
    id: 104,
    shgName: "Ponni Amman Pottery SHG",
    title: "Clay Pottery & Handicraft Unit",
    location: "Thanjavur, Tamil Nadu",
    goalAmount: BigInt("20000000000000000"),
    raisedAmount: BigInt("18000000000000000"),
    donorCount: BigInt(28),
    impactScore: BigInt(88),
    active: true, completed: false, vouchedBy: true,
    milestones: [
      { description: "Buy clay & pottery wheel",  fundAmount: BigInt("8000000000000000"), completed: true,  proofIPFSHash: "" },
      { description: "Pottery training workshop", fundAmount: BigInt("7000000000000000"), completed: true,  proofIPFSHash: "" },
      { description: "Online store & exports",    fundAmount: BigInt("5000000000000000"), completed: false, proofIPFSHash: "" },
    ],
    isExample: true,
  },
  {
    id: 105,
    shgName: "Siragugal Dairy Women SHG",
    title: "Goat Dairy Farming Initiative",
    location: "Dindigul, Tamil Nadu",
    goalAmount: BigInt("40000000000000000"),
    raisedAmount: BigInt("12000000000000000"),
    donorCount: BigInt(19),
    impactScore: BigInt(55),
    active: true, completed: false, vouchedBy: false,
    milestones: [
      { description: "Purchase dairy goats",    fundAmount: BigInt("20000000000000000"), completed: false, proofIPFSHash: "" },
      { description: "Build shelter & feed",    fundAmount: BigInt("12000000000000000"), completed: false, proofIPFSHash: "" },
      { description: "Milk processing & sales", fundAmount: BigInt("8000000000000000"),  completed: false, proofIPFSHash: "" },
    ],
    isExample: true,
  },
];

export default function Home() {
  const { crowdfund, account } = useWalletContext();
  const [campaigns, setCampaigns] = useState([]);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    if (!crowdfund) {
      setCampaigns(EXAMPLE_CAMPAIGNS);
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const count = await crowdfund.campaignCount();
        const list  = [];
        for (let i = 1; i <= Number(count); i++) {
          const c = await crowdfund.campaigns(i);
          const milestones = await crowdfund.getMilestones(i);
          list.push({ ...c, id: i, milestones });
        }
        setCampaigns([...EXAMPLE_CAMPAIGNS, ...list]);
      } catch (e) {
        console.error(e);
        setCampaigns(EXAMPLE_CAMPAIGNS);
      } finally {
        setLoading(false);
      }
    })();
  }, [crowdfund]);

  if (loading) return <div style={styles.loading}>Loading campaigns from blockchain…</div>;

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div style={styles.eyebrow}>LIVE ON-CHAIN CAMPAIGNS</div>
        <h1 style={styles.h1}>Fund Rural <span style={styles.accent}>Entrepreneurs</span></h1>
        <p style={styles.sub}>
          Every rupee tracked on-chain. Smart contracts release funds only when milestones are verified.
        </p>
      </div>
      <div style={styles.grid}>
        {campaigns.map(c => <CampaignCard key={c.id} campaign={c} />)}
      </div>
    </div>
  );
}

function CampaignCard({ campaign: c }) {
  const pct = c.goalAmount > 0
    ? Math.min(100, Math.round((Number(ethers.formatEther(c.raisedAmount)) /
        Number(ethers.formatEther(c.goalAmount))) * 100))
    : 0;
  const score = Number(c.impactScore);
  const scoreColor = score >= 80 ? "#10b981" : score >= 60 ? "#f59e0b" : "#f43f5e";

  return (
    <Link to={c.isExample ? "#" : `/campaign/${c.id}`} style={styles.card}>
      <div style={styles.cardTop}>
        <div>
          <div style={styles.shgName}>{c.shgName}</div>
          <div style={styles.location}>📍 {c.location}</div>
        </div>
        <div style={{ ...styles.scoreBadge, color: scoreColor, borderColor: scoreColor }}>
          {score}<span style={styles.scoreLabel}>SCORE</span>
        </div>
      </div>
      <div style={styles.cardBody}>
        <div style={styles.title}>{c.title}</div>
        <div style={styles.fundRow}>
          <span style={styles.raised}>{Number(ethers.formatEther(c.raisedAmount)).toFixed(3)} MATIC</span>
          <span style={{ color: scoreColor, fontWeight: 800 }}>{pct}%</span>
        </div>
        <div style={styles.progressTrack}>
          <div style={{ ...styles.progressFill, width: `${pct}%`, background: scoreColor }} />
        </div>
        <div style={styles.msRow}>
          {c.milestones.map((m, i) => (
            <div key={i} style={{ ...styles.msDot, background: m.completed ? "#10b981" : "#333" }} />
          ))}
        </div>
      </div>
      <div style={styles.cardFoot}>
        <span style={styles.donorCount}>{Number(c.donorCount)} donors</span>
        <span style={styles.goal}>Goal: {Number(ethers.formatEther(c.goalAmount)).toFixed(3)} MATIC</span>
      </div>
    </Link>
  );
}

const styles = {
  page:    { paddingTop: 100, maxWidth: 1200, margin: "0 auto", padding: "100px 2rem 4rem" },
  loading: { paddingTop: 120, textAlign: "center", color: "#888", fontSize: "1rem" },
  header:  { marginBottom: "3rem" },
  eyebrow: { fontSize: "0.62rem", letterSpacing: "0.25em", color: "#a855f7", marginBottom: 8 },
  h1:      { fontFamily: "sans-serif", fontSize: "clamp(2rem,4vw,3.2rem)", fontWeight: 900, color: "#fff", marginBottom: 12 },
  accent:  { color: "#a855f7" },
  sub:     { color: "rgba(255,255,255,0.5)", fontSize: "0.9rem", lineHeight: 1.7, maxWidth: 540 },
  grid:    { display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(320px,1fr))", gap: "1.5rem" },
  card:    { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, overflow: "hidden", textDecoration: "none", display: "block", transition: "all 0.3s" },
  cardTop: { padding: "1.2rem 1.5rem", background: "rgba(124,58,237,0.08)", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", justifyContent: "space-between", alignItems: "flex-start" },
  shgName: { color: "#fff", fontWeight: 800, fontSize: "0.9rem" },
  location: { color: "rgba(255,255,255,0.4)", fontSize: "0.62rem", marginTop: 2 },
  scoreBadge: { border: "1.5px solid", borderRadius: 8, padding: "4px 10px", fontWeight: 900, fontSize: "1rem", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center" },
  scoreLabel: { fontSize: "0.45rem", letterSpacing: "0.1em", fontWeight: 400, color: "#888", marginTop: 1 },
  cardBody: { padding: "1.2rem 1.5rem" },
  title:    { color: "rgba(255,255,255,0.85)", fontWeight: 600, fontSize: "0.95rem", lineHeight: 1.4, marginBottom: "1rem" },
  fundRow:  { display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: "0.75rem" },
  raised:   { color: "#10b981", fontWeight: 800 },
  progressTrack: { height: 7, background: "rgba(255,255,255,0.07)", borderRadius: 100, overflow: "hidden", marginBottom: "1rem" },
  progressFill:  { height: "100%", borderRadius: 100, transition: "width 1s ease" },
  msRow:    { display: "flex", gap: 6 },
  msDot:    { flex: 1, height: 5, borderRadius: 100 },
  cardFoot: { padding: "0.8rem 1.5rem", borderTop: "1px solid rgba(255,255,255,0.06)", display: "flex", justifyContent: "space-between", fontSize: "0.65rem", color: "rgba(255,255,255,0.4)" },
  donorCount: { color: "#fff" },
  goal:    { color: "rgba(255,255,255,0.4)" },
};
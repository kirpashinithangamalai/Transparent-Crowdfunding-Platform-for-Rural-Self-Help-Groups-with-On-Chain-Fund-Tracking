import React, { useState } from "react";
import { ethers } from "ethers";
import { useNavigate } from "react-router-dom";
import { useWalletContext } from "../context/WalletContext";

export default function CreateCampaign() {
  const { crowdfund, account, connect } = useWalletContext();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    shgName: "", title: "", location: "", goal: "",
  });
  const [milestones, setMilestones] = useState([
    { description: "", amount: "" },
    { description: "", amount: "" },
    { description: "", amount: "" },
  ]);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");
  const [txHash,  setTxHash]  = useState("");

  function updateField(field, val) {
    setForm(f => ({ ...f, [field]: val }));
  }
  function updateMs(i, field, val) {
    setMilestones(ms => ms.map((m, idx) => idx === i ? { ...m, [field]: val } : m));
  }
  function addMilestone() {
    if (milestones.length < 5) setMilestones(ms => [...ms, { description: "", amount: "" }]);
  }
  function removeMilestone(i) {
    if (milestones.length > 2) setMilestones(ms => ms.filter((_, idx) => idx !== i));
  }

  async function handleSubmit() {
    if (!account) { connect(); return; }
    if (!crowdfund) { setError("Contract not connected"); return; }
    setError(""); setLoading(true);

    try {
      const goalWei = ethers.parseEther(form.goal);
      const descs   = milestones.map(m => m.description);
      const amounts = milestones.map(m => ethers.parseEther(m.amount));

      const totalMs = amounts.reduce((a, b) => a + b, 0n);
      if (totalMs !== goalWei) {
        setError("Milestone amounts must add up to goal amount");
        setLoading(false); return;
      }

      const tx = await crowdfund.createCampaign(
        form.shgName, form.title, form.location,
        goalWei, descs, amounts,
        {
          gasPrice: ethers.parseUnits("50", "gwei")
        }
      );
      setTxHash(tx.hash);
      await tx.wait();
      navigate("/");
    } catch (e) {
      setError(e.reason || e.message || "Transaction failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.heading}>🚀 Create New SHG Campaign</div>
        <p style={styles.sub}>
          Deploy a smart contract campaign. Funds are held in escrow and released only when you submit milestone proof.
        </p>

        <label style={styles.label}>SHG NAME</label>
        <input style={styles.input} placeholder="e.g. Kaveri Women's Collective"
          value={form.shgName} onChange={e => updateField("shgName", e.target.value)} />

        <label style={styles.label}>CAMPAIGN TITLE</label>
        <input style={styles.input} placeholder="e.g. Organic Vegetable Farming Expansion"
          value={form.title} onChange={e => updateField("title", e.target.value)} />

        <label style={styles.label}>LOCATION</label>
        <input style={styles.input} placeholder="e.g. Tamil Nadu"
          value={form.location} onChange={e => updateField("location", e.target.value)} />

        <label style={styles.label}>TOTAL GOAL (MATIC)</label>
        <input style={styles.input} type="number" placeholder="e.g. 5.0"
          value={form.goal} onChange={e => updateField("goal", e.target.value)} />

        <div style={styles.msHeader}>
          <label style={styles.label}>MILESTONES</label>
          <button style={styles.addBtn} onClick={addMilestone}>+ Add</button>
        </div>
        {milestones.map((m, i) => (
          <div key={i} style={styles.msRow}>
            <span style={styles.msNum}>{i + 1}</span>
            <input style={{ ...styles.input, flex: 2, margin: 0 }}
              placeholder={`Milestone ${i + 1} description`}
              value={m.description} onChange={e => updateMs(i, "description", e.target.value)} />
            <input style={{ ...styles.input, flex: 1, margin: 0 }}
              type="number" placeholder="MATIC"
              value={m.amount} onChange={e => updateMs(i, "amount", e.target.value)} />
            {milestones.length > 2 &&
              <button style={styles.removeBtn} onClick={() => removeMilestone(i)}>✕</button>}
          </div>
        ))}

        {error && <div style={styles.error}>{error}</div>}
        {txHash && (
          <div style={styles.success}>
            ✅ TX submitted: <a style={{color:"#a855f7"}} href={`https://amoy.polygonscan.com/tx/${txHash}`} target="_blank" rel="noreferrer">{txHash.substring(0,20)}...</a>
          </div>
        )}

        <button style={styles.btn} onClick={handleSubmit} disabled={loading}>
          {!account ? "🦊 Connect MetaMask First" : loading ? "Deploying to Blockchain..." : "Deploy Campaign →"}
        </button>
      </div>
    </div>
  );
}

const styles = {
  page:    { paddingTop: 100, maxWidth: 680, margin: "0 auto", padding: "100px 2rem 4rem" },
  card:    { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: "2.5rem" },
  heading: { fontWeight: 900, fontSize: "1.4rem", color: "#fff", marginBottom: 8 },
  sub:     { color: "rgba(255,255,255,0.5)", fontSize: "0.82rem", lineHeight: 1.7, marginBottom: "2rem" },
  label:   { display: "block", fontSize: "0.6rem", letterSpacing: "0.15em", color: "rgba(255,255,255,0.4)", marginBottom: 6, marginTop: "1.2rem" },
  input:   { width: "100%", background: "rgba(255,255,255,0.05)", border: "1.5px solid rgba(255,255,255,0.1)", borderRadius: 10, color: "#fff", fontFamily: "inherit", fontSize: "0.85rem", padding: "12px 14px", outline: "none", boxSizing: "border-box" },
  msHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "1.2rem" },
  addBtn:  { background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)", color: "#a855f7", padding: "5px 12px", borderRadius: 6, cursor: "pointer", fontSize: "0.75rem", fontWeight: 700 },
  msRow:   { display: "flex", gap: 8, alignItems: "center", marginBottom: 8, marginTop: 6 },
  msNum:   { color: "#a855f7", fontWeight: 900, fontSize: "1rem", width: 20, flexShrink: 0 },
  removeBtn: { background: "transparent", border: "1px solid rgba(244,63,94,0.3)", color: "#f43f5e", width: 30, height: 30, borderRadius: 6, cursor: "pointer", flexShrink: 0 },
  error:   { background: "rgba(244,63,94,0.1)", border: "1px solid rgba(244,63,94,0.3)", color: "#f87171", borderRadius: 8, padding: "10px 14px", fontSize: "0.78rem", marginTop: "1rem" },
  success: { background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#34d399", borderRadius: 8, padding: "10px 14px", fontSize: "0.78rem", marginTop: "1rem" },
  btn:     { width: "100%", marginTop: "2rem", background: "linear-gradient(135deg,#7c3aed,#ec4899)", color: "#fff", border: "none", borderRadius: 12, padding: "14px", fontWeight: 900, fontSize: "0.9rem", cursor: "pointer" },
};
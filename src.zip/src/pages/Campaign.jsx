import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { ethers } from "ethers";
import { useWalletContext } from "../context/WalletContext";

export default function Campaign() {
  const { id } = useParams();
  const { crowdfund, account, connect } = useWalletContext();
  const [campaign,   setCampaign]   = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [amount,     setAmount]     = useState("0.05");
  const [proof,      setProof]      = useState("");
  const [msIndex,    setMsIndex]    = useState(0);
  const [loading,    setLoading]    = useState(false);
  const [txMsg,      setTxMsg]      = useState("");

  async function loadCampaign() {
    if (!crowdfund) return;
    const c  = await crowdfund.campaigns(id);
    const ms = await crowdfund.getMilestones(id);
    setCampaign(c);
    setMilestones(ms);
  }

  useEffect(() => { loadCampaign(); }, [crowdfund, id]);

  async function donate() {
    if (!account) { connect(); return; }
    setLoading(true); setTxMsg("");
    try {
      const tx = await crowdfund.donate(id, { value: ethers.parseEther(amount) });
      setTxMsg("Submitting…");
      await tx.wait();
      setTxMsg("✅ Donation confirmed! Funds locked in escrow.");
      loadCampaign();
    } catch (e) { setTxMsg("❌ " + (e.reason || e.message)); }
    setLoading(false);
  }

  async function submitProof() {
    if (!account) { connect(); return; }
    setLoading(true); setTxMsg("");
    try {
      const tx = await crowdfund.submitMilestoneProof(id, msIndex, proof);
      setTxMsg("Submitting proof…");
      await tx.wait();
      setTxMsg("✅ Milestone verified! Funds auto-released to SHG.");
      loadCampaign();
    } catch (e) { setTxMsg("❌ " + (e.reason || e.message)); }
    setLoading(false);
  }

  if (!campaign) return <div style={pg.loading}>Loading campaign…</div>;

  const pct = campaign.goalAmount > 0
    ? Math.min(100, Math.round(
        Number(ethers.formatEther(campaign.raisedAmount)) /
        Number(ethers.formatEther(campaign.goalAmount)) * 100))
    : 0;
  const score = Number(campaign.impactScore);
  const sc    = score >= 80 ? "#10b981" : score >= 60 ? "#f59e0b" : "#f43f5e";
  const isSHGOwner = account?.toLowerCase() === campaign.shgAddress.toLowerCase();

  return (
    <div style={pg.page}>
      {/* Header */}
      <div style={pg.header}>
        <div style={pg.eyebrow}>📍 {campaign.location}</div>
        <h1 style={pg.h1}>{campaign.title}</h1>
        <div style={pg.shgName}>by {campaign.shgName}</div>
        <div style={{ ...pg.scoreBig, color: sc }}>Impact Score: {score}/100</div>
      </div>

      <div style={pg.grid}>
        {/* Left: milestones */}
        <div>
          <div style={pg.sectionTitle}>Milestone Escrow</div>
          {milestones.map((m, i) => (
            <div key={i} style={{ ...pg.msCard, borderColor: m.completed ? "#10b981" : "rgba(255,255,255,0.1)" }}>
              <div style={pg.msTop}>
                <span style={{ ...pg.msBadge, background: m.completed ? "#10b981" : "#333" }}>
                  {m.completed ? "✓ DONE" : `M${i + 1}`}
                </span>
                <span style={pg.msDesc}>{m.description}</span>
                <span style={{ color: "#10b981", fontWeight: 800 }}>
                  {Number(ethers.formatEther(m.fundAmount)).toFixed(2)} MATIC
                </span>
              </div>
              {m.completed && m.proofIPFSHash && (
                <div style={pg.proof}>
                  🔗 IPFS Proof: <a href={`https://ipfs.io/ipfs/${m.proofIPFSHash}`}
                    target="_blank" rel="noreferrer" style={{ color: "#a855f7" }}>
                    {m.proofIPFSHash.substring(0, 20)}…
                  </a>
                </div>
              )}
            </div>
          ))}

          {/* SHG: submit milestone proof */}
          {isSHGOwner && (
            <div style={pg.card}>
              <div style={pg.cardTitle}>Submit Milestone Proof</div>
              <select style={pg.input} value={msIndex} onChange={e => setMsIndex(Number(e.target.value))}>
                {milestones.map((_, i) => <option key={i} value={i}>Milestone {i + 1}</option>)}
              </select>
              <input style={pg.input} placeholder="IPFS hash of proof document (QmXxx…)"
                value={proof} onChange={e => setProof(e.target.value)} />
              <button style={pg.btnGreen} onClick={submitProof} disabled={loading}>
                Submit Proof → Auto-Release Funds
              </button>
            </div>
          )}
        </div>

        {/* Right: donate */}
        <div>
          <div style={pg.card}>
            <div style={pg.cardTitle}>Fund This Campaign</div>
            <div style={pg.statsRow}>
              <div style={pg.stat}>
                <div style={{ color: "#10b981", fontWeight: 900, fontSize: "1.4rem" }}>
                  {Number(ethers.formatEther(campaign.raisedAmount)).toFixed(2)}
                </div>
                <div style={pg.statLabel}>MATIC RAISED</div>
              </div>
              <div style={pg.stat}>
                <div style={{ color: "#a855f7", fontWeight: 900, fontSize: "1.4rem" }}>
                  {pct}%
                </div>
                <div style={pg.statLabel}>FUNDED</div>
              </div>
              <div style={pg.stat}>
                <div style={{ color: "#f59e0b", fontWeight: 900, fontSize: "1.4rem" }}>
                  {Number(campaign.donorCount)}
                </div>
                <div style={pg.statLabel}>DONORS</div>
              </div>
            </div>
            <div style={pg.track}><div style={{ ...pg.fill, width: `${pct}%` }} /></div>

            <label style={pg.label}>AMOUNT (TEST MATIC)</label>
            <input style={pg.input} type="number" min="0.001" step="0.001"
              value={amount} onChange={e => setAmount(e.target.value)} />

            <div style={pg.note}>
              ✓ Funds locked in smart contract escrow<br/>
              ✓ Released only when milestone proof verified<br/>
              ✓ SBT badge issued on campaign completion
            </div>

            {txMsg && <div style={txMsg.startsWith("✅") ? pg.success : pg.error}>{txMsg}</div>}

            <button style={pg.btnDonate} onClick={donate} disabled={loading || campaign.completed}>
              {!account ? "🦊 Connect Wallet to Donate" : loading ? "Processing…" : campaign.completed ? "Campaign Complete" : "Donate →"}
            </button>
          </div>

          <div style={pg.card}>
            <div style={pg.cardTitle}>On-Chain Details</div>
            <div style={pg.detail}><span>SHG Address</span><span style={{color:"#a855f7",fontSize:"0.7rem"}}>{campaign.shgAddress.substring(0,16)}…</span></div>
            <div style={pg.detail}><span>Status</span><span style={{color: campaign.active ? "#10b981" : "#f59e0b"}}>{campaign.completed ? "Completed" : campaign.active ? "Active" : "Inactive"}</span></div>
            <div style={pg.detail}><span>Vouched</span><span>{campaign.vouchedBy ? "✅ Yes" : "—"}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

const pg = {
  page:      { paddingTop: 100, maxWidth: 1100, margin: "0 auto", padding: "100px 2rem 4rem" },
  loading:   { paddingTop: 120, textAlign: "center", color: "#888" },
  header:    { marginBottom: "2.5rem" },
  eyebrow:   { fontSize: "0.65rem", letterSpacing: "0.2em", color: "rgba(255,255,255,0.4)", marginBottom: 8 },
  h1:        { color: "#fff", fontWeight: 900, fontSize: "clamp(1.6rem,3vw,2.6rem)", lineHeight: 1.2, marginBottom: 8 },
  shgName:   { color: "#a855f7", fontWeight: 700, fontSize: "0.9rem", marginBottom: 6 },
  scoreBig:  { fontWeight: 900, fontSize: "1rem" },
  grid:      { display: "grid", gridTemplateColumns: "1.2fr 0.8fr", gap: "2rem" },
  sectionTitle: { color: "#fff", fontWeight: 800, fontSize: "1rem", marginBottom: "1rem" },
  msCard:    { background: "rgba(255,255,255,0.03)", border: "1px solid", borderRadius: 10, padding: "1rem", marginBottom: 8 },
  msTop:     { display: "flex", alignItems: "center", gap: 10, fontSize: "0.8rem" },
  msBadge:   { padding: "3px 8px", borderRadius: 4, fontSize: "0.58rem", fontWeight: 800, color: "#fff", flexShrink: 0 },
  msDesc:    { flex: 1, color: "rgba(255,255,255,0.8)" },
  proof:     { marginTop: 8, fontSize: "0.65rem", color: "rgba(255,255,255,0.5)" },
  card:      { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, padding: "1.5rem", marginBottom: "1.5rem" },
  cardTitle: { color: "#fff", fontWeight: 800, fontSize: "0.9rem", marginBottom: "1.2rem" },
  statsRow:  { display: "flex", gap: "1rem", marginBottom: "1.2rem" },
  stat:      { flex: 1, textAlign: "center" },
  statLabel: { fontSize: "0.58rem", letterSpacing: "0.1em", color: "rgba(255,255,255,0.4)", marginTop: 2 },
  track:     { height: 8, background: "rgba(255,255,255,0.07)", borderRadius: 100, overflow: "hidden", marginBottom: "1.5rem" },
  fill:      { height: "100%", background: "linear-gradient(90deg,#7c3aed,#ec4899)", borderRadius: 100, transition: "width 1s" },
  label:     { display: "block", fontSize: "0.6rem", letterSpacing: "0.15em", color: "rgba(255,255,255,0.4)", marginBottom: 6 },
  input:     { width: "100%", background: "rgba(255,255,255,0.05)", border: "1.5px solid rgba(255,255,255,0.1)", borderRadius: 10, color: "#fff", fontFamily: "inherit", fontSize: "0.85rem", padding: "10px 14px", outline: "none", boxSizing: "border-box", marginBottom: "1rem" },
  note:      { background: "rgba(16,185,129,0.06)", border: "1px solid rgba(16,185,129,0.15)", borderRadius: 8, padding: "10px 14px", fontSize: "0.68rem", color: "rgba(255,255,255,0.6)", lineHeight: 1.8, marginBottom: "1rem" },
  error:     { background: "rgba(244,63,94,0.1)", border: "1px solid rgba(244,63,94,0.3)", color: "#f87171", borderRadius: 8, padding: "8px 12px", fontSize: "0.75rem", marginBottom: 12 },
  success:   { background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#34d399", borderRadius: 8, padding: "8px 12px", fontSize: "0.75rem", marginBottom: 12 },
  btnDonate: { width: "100%", background: "linear-gradient(135deg,#7c3aed,#ec4899)", color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontWeight: 900, fontSize: "0.85rem", cursor: "pointer" },
  btnGreen:  { width: "100%", background: "linear-gradient(135deg,#065f46,#10b981)", color: "#fff", border: "none", borderRadius: 10, padding: "12px", fontWeight: 800, fontSize: "0.82rem", cursor: "pointer", marginTop: 4 },
  detail:    { display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.06)", fontSize: "0.72rem", color: "rgba(255,255,255,0.5)" },
};

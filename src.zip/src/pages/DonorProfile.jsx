import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { useWalletContext } from "../context/WalletContext";

export default function DonorProfile() {
  const { sbt, crowdfund, account, connect } = useWalletContext();
  const [badges,  setBadges]  = useState([]);
  const [donated, setDonated] = useState("0");

  useEffect(() => {
    if (!sbt || !crowdfund || !account) return;
    (async () => {
      const tokenIds = await sbt.getMyBadges(account);
      const list = [];
      for (const id of tokenIds) {
        const data = await sbt.tokens(id);
        list.push(data);
      }
      setBadges(list);
      const d = await crowdfund.getDonorInfo(account);
      setDonated(ethers.formatEther(d.totalDonated));
    })();
  }, [sbt, crowdfund, account]);

  if (!account) return (
    <div style={s.page}>
      <div style={s.center}>
        <div style={s.h1}>Connect your wallet to view your profile</div>
        <button style={s.btn} onClick={connect}>🦊 Connect MetaMask</button>
      </div>
    </div>
  );

  return (
    <div style={s.page}>
      <div style={s.eyebrow}>MY DONOR PROFILE</div>
      <h1 style={s.h1}>Your <span style={{color:"#ec4899"}}>Impact</span></h1>
      <div style={s.address}>{account}</div>
      <div style={s.stat}>Total donated: <strong style={{color:"#10b981"}}>{Number(donated).toFixed(4)} MATIC</strong></div>

      <div style={s.sectionTitle}>🎖️ Soul-Bound Token Badges ({badges.length})</div>
      {badges.length === 0 ? (
        <div style={s.empty}>No SBT badges yet. Fund a campaign to completion to earn one!</div>
      ) : (
        <div style={s.grid}>
          {badges.map((b, i) => (
            <div key={i} style={s.badge}>
              <div style={s.badgeIcon}>🎖️</div>
              <div style={s.badgeName}>{b.shgName}</div>
              <div style={s.badgeMeta}>Campaign #{Number(b.campaignId)}</div>
              <div style={s.badgeMeta}>Donated: {ethers.formatEther(b.amountDonated)} MATIC</div>
              <div style={s.badgeLock}>🔒 Soul-Bound — Non-transferable</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const s = {
  page:        { paddingTop:100, maxWidth:1000, margin:"0 auto", padding:"100px 2rem 4rem" },
  center:      { textAlign:"center", padding:"4rem 0" },
  eyebrow:     { fontSize:"0.62rem", letterSpacing:"0.25em", color:"#ec4899", marginBottom:8 },
  h1:          { color:"#fff", fontWeight:900, fontSize:"clamp(1.8rem,3vw,2.8rem)", marginBottom:8 },
  address:     { color:"rgba(255,255,255,0.4)", fontSize:"0.72rem", fontFamily:"monospace", marginBottom:8 },
  stat:        { color:"rgba(255,255,255,0.6)", fontSize:"0.85rem", marginBottom:"2.5rem" },
  sectionTitle:{ color:"#fff", fontWeight:800, fontSize:"1rem", marginBottom:"1.2rem" },
  empty:       { color:"#666", fontSize:"0.85rem" },
  grid:        { display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))", gap:"1rem" },
  badge:       { background:"linear-gradient(135deg,rgba(236,72,153,0.1),rgba(124,58,237,0.1))", border:"1px solid rgba(236,72,153,0.3)", borderRadius:16, padding:"1.5rem", textAlign:"center" },
  badgeIcon:   { fontSize:"2.5rem", marginBottom:8 },
  badgeName:   { color:"#fff", fontWeight:800, fontSize:"0.85rem", marginBottom:6 },
  badgeMeta:   { color:"rgba(255,255,255,0.5)", fontSize:"0.65rem", marginBottom:3 },
  badgeLock:   { color:"#ec4899", fontSize:"0.6rem", marginTop:8 },
  btn:         { background:"linear-gradient(135deg,#7c3aed,#ec4899)", color:"#fff", border:"none", borderRadius:10, padding:"12px 28px", fontWeight:800, fontSize:"0.85rem", cursor:"pointer", marginTop:16 },
};

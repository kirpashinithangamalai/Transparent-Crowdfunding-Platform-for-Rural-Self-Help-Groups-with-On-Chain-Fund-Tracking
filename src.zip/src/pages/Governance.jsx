import React, { useEffect, useState } from "react";
import { useWalletContext } from "../context/WalletContext";

export default function Governance() {
  const { governance, crowdfund, account, connect } = useWalletContext();
  const [proposals, setProposals] = useState([]);
  const [loading,   setLoading]   = useState(false);
  const [msg,       setMsg]       = useState("");

  useEffect(() => {
    if (!governance || !crowdfund) return;
    loadProposals();
  }, [governance, crowdfund]);

  async function loadProposals() {
    try {
      const count = await crowdfund.campaignCount();
      const list  = [];
      for (let i = 1; i <= Number(count); i++) {
        const p = await governance.getProposal(i);
        if (p.deadline > 0) {
          const c = await crowdfund.campaigns(i);
          list.push({ campaignId: i, shgName: c.shgName,
            yes: Number(p.yes), no: Number(p.no),
            deadline: Number(p.deadline), executed: p.executed, passed: p.passed });
        }
      }
      setProposals(list);
    } catch (e) { console.error(e); }
  }

  async function vote(campaignId, voteRefund) {
    if (!account) { connect(); return; }
    setLoading(true); setMsg("");
    try {
      const tx = await governance.castVote(campaignId, voteRefund);
      await tx.wait();
      setMsg("✅ Vote cast on-chain!");
      loadProposals();
    } catch (e) { setMsg("❌ " + (e.reason || e.message)); }
    setLoading(false);
  }

  async function execute(campaignId) {
    setLoading(true);
    try {
      const tx = await governance.executeProposal(campaignId);
      await tx.wait();
      setMsg("✅ Proposal executed automatically by smart contract.");
      loadProposals();
    } catch (e) { setMsg("❌ " + (e.reason || e.message)); }
    setLoading(false);
  }

  const now = Math.floor(Date.now() / 1000);

  return (
    <div style={s.page}>
      <div style={s.eyebrow}>DECENTRALISED GOVERNANCE</div>
      <h1 style={s.h1}>Refund Vote <span style={{color:"#f59e0b"}}>Dashboard</span></h1>
      <p style={s.sub}>
        If an SHG misses 2 consecutive milestones, donors vote to refund remaining escrowed funds.
        The 48-hour window closes automatically — majority vote executes the smart contract.
      </p>

      {msg && <div style={msg.startsWith("✅") ? s.success : s.error}>{msg}</div>}

      {proposals.length === 0 ? (
        <div style={s.empty}>No active governance proposals. All SHGs are on track! ✅</div>
      ) : proposals.map(p => {
        const total    = p.yes + p.no || 1;
        const yesPct   = Math.round((p.yes / total) * 100);
        const noPct    = 100 - yesPct;
        const isOpen   = now < p.deadline && !p.executed;
        const canExec  = now >= p.deadline && !p.executed;
        const timeLeft = p.deadline - now;
        const hrs      = Math.floor(timeLeft / 3600);
        const mins     = Math.floor((timeLeft % 3600) / 60);

        return (
          <div key={p.campaignId} style={s.card}>
            <div style={s.cardTop}>
              <div>
                <div style={s.shg}>⚖️ {p.shgName}</div>
                <div style={s.issue}>Missed 2 consecutive milestones — donor vote required</div>
              </div>
              <div style={{ ...s.pill, background: isOpen ? "rgba(245,158,11,0.15)" : "transparent", borderColor: isOpen ? "rgba(245,158,11,0.4)" :"transparent",color:"#f59e0b" }}>
                {p.executed ? "EXECUTED" : canExec ? "READY TO EXECUTE" : `${hrs}h ${mins}m left`}
              </div>
            </div>
            <div style={s.voteTrack}>
              <div style={{ ...s.yesBar, width: `${yesPct}%` }} />
              <div style={{ ...s.noBar,  width: `${noPct}%`  }} />
            </div>
            <div style={s.voteLabels}>
              <span style={{color:"#10b981", fontWeight:700}}>✅ Refund {yesPct}% ({p.yes} votes)</span>
              <span style={{color:"#f43f5e", fontWeight:700}}>❌ Continue {noPct}% ({p.no} votes)</span>
            </div>
            {isOpen && (
              <div style={s.btnRow}>
                <button style={s.btnYes} onClick={() => vote(p.campaignId, true)}  disabled={loading}>Vote Refund</button>
                <button style={s.btnNo}  onClick={() => vote(p.campaignId, false)} disabled={loading}>Vote Continue</button>
              </div>
            )}
            {canExec && (
              <button style={s.btnExec} onClick={() => execute(p.campaignId)} disabled={loading}>
                Execute Result (Smart Contract Auto-Refund)
              </button>
            )}
            {p.executed && (
              <div style={s.result}>
                Result: {p.passed ? "🔴 REFUND EXECUTED" : "🟢 CAMPAIGN CONTINUES"}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

const s = {
  page:    { paddingTop: 100, maxWidth: 860, margin: "0 auto", padding: "100px 2rem 4rem" },
  eyebrow: { fontSize: "0.62rem", letterSpacing: "0.25em", color: "#f59e0b", marginBottom: 8 },
  h1:      { color: "#fff", fontWeight: 900, fontSize: "clamp(1.8rem,3vw,2.8rem)", marginBottom: 10 },
  sub:     { color: "rgba(255,255,255,0.5)", fontSize: "0.85rem", lineHeight: 1.7, marginBottom: "2.5rem", maxWidth: 640 },
  empty:   { textAlign: "center", color: "#666", padding: "4rem 0", fontSize: "1rem" },
  card:    { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: "1.8rem", marginBottom: "1.5rem" },
  cardTop: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1.5rem" },
  shg:     { color: "#fff", fontWeight: 800, fontSize: "1rem", marginBottom: 4 },
  issue:   { color: "rgba(255,255,255,0.5)", fontSize: "0.75rem" },
  pill:    { border: "1px solid", padding: "6px 14px", borderRadius: 100, fontSize: "0.65rem", fontWeight: 700, whiteSpace: "nowrap" },
  voteTrack: { display: "flex", height: 10, borderRadius: 100, overflow: "hidden", background: "rgba(255,255,255,0.07)", marginBottom: 8 },
  yesBar:  { background: "linear-gradient(90deg,#065f46,#10b981)", borderRadius: 100, transition: "width 0.8s" },
  noBar:   { background: "linear-gradient(90deg,#9f1239,#f43f5e)", borderRadius: 100, transition: "width 0.8s" },
  voteLabels: { display: "flex", justifyContent: "space-between", fontSize: "0.7rem", marginBottom: "1.2rem" },
  btnRow:  { display: "flex", gap: 12 },
  btnYes:  { flex: 1, background: "transparent", border: "1.5px solid rgba(16,185,129,0.4)", color: "#10b981", borderRadius: 8, padding: "10px", fontWeight: 800, fontSize: "0.78rem", cursor: "pointer" },
  btnNo:   { flex: 1, background: "transparent", border: "1.5px solid rgba(244,63,94,0.4)", color: "#f43f5e", borderRadius: 8, padding: "10px", fontWeight: 800, fontSize: "0.78rem", cursor: "pointer" },
  btnExec: { width: "100%", background: "linear-gradient(135deg,#92400e,#f59e0b)", color: "#fff", border: "none", borderRadius: 8, padding: "12px", fontWeight: 800, fontSize: "0.8rem", cursor: "pointer", marginTop: 8 },
  result:  { marginTop: 12, padding: "10px 14px", background: "rgba(255,255,255,0.04)", borderRadius: 8, fontSize: "0.78rem", fontWeight: 700, color: "#fff" },
  error:   { background: "rgba(244,63,94,0.1)", border: "1px solid rgba(244,63,94,0.3)", color: "#f87171", borderRadius: 8, padding: "10px 14px", fontSize: "0.78rem", marginBottom: 16 },
  success: { background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#34d399", borderRadius: 8, padding: "10px 14px", fontSize: "0.78rem", marginBottom: 16 },
};

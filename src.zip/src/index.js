import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// Global dark styles
const style = document.createElement("style");
style.textContent = `
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'Cabinet Grotesk',system-ui,sans-serif; background:#050510; color:#fff; }
  @import url('https://fonts.googleapis.com/css2?family=Cabinet+Grotesk:wght@400;500;700;800;900&display=swap');
  button { font-family: inherit; }
  input, select { color-scheme: dark; }
  ::-webkit-scrollbar { width:6px; }
  ::-webkit-scrollbar-track { background:#0a0a20; }
  ::-webkit-scrollbar-thumb { background:#3b0764; border-radius:3px; }
`;
document.head.appendChild(style);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useWalletContext } from "../../context/WalletContext";

export default function Navbar() {
  const { account, connect, disconnect, shortAddress, isCorrectNetwork, loading, error } =
    useWalletContext();
  const loc = useLocation();

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.logo}>⬡ SHGChain</Link>

      <div style={styles.links}>
        {[
          ["/",           "Campaigns"],
          ["/create",     "+ New Campaign"],
          ["/governance", "Governance"],
          ["/profile",    "My Profile"],
          ["/dashboard",  "Dashboard"],
        ].map(([path, label]) => (
          <Link key={path} to={path}
            style={{ ...styles.link, ...(loc.pathname === path ? styles.activeLink : {}) }}>
            {label}
          </Link>
        ))}
      </div>

      <div style={styles.right}>
        {/* Network indicator */}
        {account && (
          <div style={{ ...styles.networkPill, background: isCorrectNetwork ? "#0d2" : "#d30" }}>
            {isCorrectNetwork ? "● Polygon Amoy" : "⚠ Wrong Network"}
          </div>
        )}

        {/* Wallet button */}
        {account ? (
          <div style={styles.walletRow}>
            <span style={styles.address}>{shortAddress}</span>
            <button style={styles.btnDisconnect} onClick={disconnect}>Disconnect</button>
          </div>
        ) : (
          <button style={styles.btnConnect} onClick={connect} disabled={loading}>
            {loading ? "Connecting…" : "🦊 Connect MetaMask"}
          </button>
        )}
      </div>

      {error && <div style={styles.error}>{error}</div>}
    </nav>
  );
}

const styles = {
  nav: {
    position:"fixed", top:0, left:0, right:0, zIndex:1000,
    display:"flex", alignItems:"center", justifyContent:"space-between",
    padding:"0 2rem", height:64,
    background:"rgba(5,5,20,0.95)",
    backdropFilter:"blur(20px)",
    borderBottom:"1px solid rgba(255,255,255,0.08)",
  },
  logo: {
    fontWeight:900, fontSize:"1.25rem", color:"#a855f7",
    textDecoration:"none", letterSpacing:"-0.02em",
  },
  links: { display:"flex", gap:"1.5rem", alignItems:"center" },
  link:  { color:"rgba(255,255,255,0.55)", textDecoration:"none", fontSize:"0.82rem" },
  activeLink: { color:"#fff", fontWeight:700 },
  right: { display:"flex", alignItems:"center", gap:"12px" },
  networkPill: {
    padding:"5px 12px", borderRadius:100,
    fontSize:"0.65rem", color:"#fff", fontWeight:700,
  },
  walletRow: { display:"flex", alignItems:"center", gap:8 },
  address: {
    background:"rgba(168,85,247,0.15)",
    border:"1px solid rgba(168,85,247,0.3)",
    color:"#c084fc", padding:"6px 14px", borderRadius:8, fontSize:"0.75rem",
  },
  btnConnect: {
    background:"linear-gradient(135deg,#7c3aed,#ec4899)",
    color:"#fff", border:"none", cursor:"pointer",
    padding:"10px 20px", borderRadius:8,
    fontWeight:800, fontSize:"0.78rem",
  },
  btnDisconnect: {
    background:"transparent", border:"1px solid rgba(255,255,255,0.15)",
    color:"rgba(255,255,255,0.5)", cursor:"pointer",
    padding:"6px 12px", borderRadius:8, fontSize:"0.7rem",
  },
  error: {
    position:"absolute", bottom:-32, left:"50%", transform:"translateX(-50%)",
    background:"#c0392b", color:"#fff", padding:"4px 16px",
    borderRadius:4, fontSize:"0.72rem",
  },
};

const { expect } = require("chai");
const { ethers }  = require("hardhat");

describe("SHGCrowdfund", function () {
  let crowdfund, sbt, governance;
  let owner, shg1, shg2, donor1, donor2;

  beforeEach(async () => {
    [owner, shg1, shg2, donor1, donor2] = await ethers.getSigners();

    const SHGCrowdfund    = await ethers.getContractFactory("SHGCrowdfund");
    const SoulBoundToken  = await ethers.getContractFactory("SoulBoundToken");
    const RefundGovernance = await ethers.getContractFactory("RefundGovernance");

    crowdfund  = await SHGCrowdfund.deploy();
    sbt        = await SoulBoundToken.deploy(await crowdfund.getAddress());
    governance = await RefundGovernance.deploy(await crowdfund.getAddress());
  });

  // ─── CAMPAIGN CREATION ───────────────────────────────────────
  describe("Campaign Creation", () => {
    it("should create a campaign with milestones", async () => {
      const goal = ethers.parseEther("3.0");
      await crowdfund.connect(shg1).createCampaign(
        "Test SHG", "Test Campaign", "Tamil Nadu", goal,
        ["Milestone 1", "Milestone 2", "Milestone 3"],
        [ethers.parseEther("1"), ethers.parseEther("1"), ethers.parseEther("1")]
      );
      const c = await crowdfund.campaigns(1);
      expect(c.shgName).to.equal("Test SHG");
      expect(c.goalAmount).to.equal(goal);
      expect(c.active).to.be.true;
    });

    it("should reject if milestone amounts don't sum to goal", async () => {
      await expect(
        crowdfund.connect(shg1).createCampaign(
          "Bad SHG", "Bad Campaign", "Delhi", ethers.parseEther("5"),
          ["M1", "M2"],
          [ethers.parseEther("1"), ethers.parseEther("1")] // only 2, not 5
        )
      ).to.be.revertedWith("Milestone amounts must equal goal");
    });
  });

  // ─── DONATIONS ───────────────────────────────────────────────
  describe("Donations", () => {
    beforeEach(async () => {
      await crowdfund.connect(shg1).createCampaign(
        "Kaveri SHG", "Farming", "TN",
        ethers.parseEther("3"),
        ["M1", "M2", "M3"],
        [ethers.parseEther("1"), ethers.parseEther("1"), ethers.parseEther("1")]
      );
    });

    it("should accept donations and update raised amount", async () => {
      await crowdfund.connect(donor1).donate(1, { value: ethers.parseEther("0.5") });
      const c = await crowdfund.campaigns(1);
      expect(c.raisedAmount).to.equal(ethers.parseEther("0.5"));
      expect(c.donorCount).to.equal(1);
    });

    it("should lock funds in escrow", async () => {
      await crowdfund.connect(donor1).donate(1, { value: ethers.parseEther("1.0") });
      const bal = await crowdfund.getContractBalance();
      expect(bal).to.equal(ethers.parseEther("1.0"));
    });

    it("should reject zero donations", async () => {
      await expect(
        crowdfund.connect(donor1).donate(1, { value: 0 })
      ).to.be.revertedWith("Must send MATIC");
    });
  });

  // ─── MILESTONE RELEASE ───────────────────────────────────────
  describe("Milestone-Based Fund Release", () => {
    beforeEach(async () => {
      await crowdfund.connect(shg1).createCampaign(
        "Kaveri SHG", "Farming", "TN",
        ethers.parseEther("3"),
        ["M1", "M2", "M3"],
        [ethers.parseEther("1"), ethers.parseEther("1"), ethers.parseEther("1")]
      );
      await crowdfund.connect(donor1).donate(1, { value: ethers.parseEther("3") });
    });

    it("should release funds only on proof submission", async () => {
      const before = await ethers.provider.getBalance(shg1.address);
      await crowdfund.connect(shg1).submitMilestoneProof(1, 0, "QmTestHash123");
      const after = await ethers.provider.getBalance(shg1.address);
      expect(after).to.be.gt(before);
    });

    it("should reject milestone out of order", async () => {
      await expect(
        crowdfund.connect(shg1).submitMilestoneProof(1, 1, "QmHash") // skip M1
      ).to.be.revertedWith("Previous milestone not done");
    });

    it("should reject proof from non-SHG address", async () => {
      await expect(
        crowdfund.connect(donor1).submitMilestoneProof(1, 0, "QmHash")
      ).to.be.revertedWith("Only SHG owner");
    });

    it("should mark campaign complete when all milestones done", async () => {
      await crowdfund.connect(shg1).submitMilestoneProof(1, 0, "QmHash1");
      await crowdfund.connect(shg1).submitMilestoneProof(1, 1, "QmHash2");
      await crowdfund.connect(shg1).submitMilestoneProof(1, 2, "QmHash3");
      const c = await crowdfund.campaigns(1);
      expect(c.completed).to.be.true;
      expect(c.active).to.be.false;
    });
  });

  // ─── IMPACT SCORE ────────────────────────────────────────────
  describe("Impact Score", () => {
    it("should increase score as milestones complete", async () => {
      await crowdfund.connect(shg1).createCampaign(
        "SHG", "Camp", "TN", ethers.parseEther("2"),
        ["M1","M2"], [ethers.parseEther("1"), ethers.parseEther("1")]
      );
      await crowdfund.connect(donor1).donate(1, {value: ethers.parseEther("2")});
      const before = (await crowdfund.campaigns(1)).impactScore;
      await crowdfund.connect(shg1).submitMilestoneProof(1, 0, "QmHash");
      const after = (await crowdfund.campaigns(1)).impactScore;
      expect(after).to.be.gt(before);
    });
  });

  // ─── PEER VOUCHING ───────────────────────────────────────────
  describe("Peer Vouching", () => {
    it("should reject vouch if score below 70", async () => {
      await crowdfund.connect(shg1).createCampaign(
        "SHG1","C1","TN",ethers.parseEther("2"),["M1","M2"],
        [ethers.parseEther("1"),ethers.parseEther("1")]
      );
      await crowdfund.connect(shg2).createCampaign(
        "SHG2","C2","MH",ethers.parseEther("2"),["M1","M2"],
        [ethers.parseEther("1"),ethers.parseEther("1")]
      );
      await expect(
        crowdfund.connect(shg1).vouchForCampaign(2, 1)
      ).to.be.revertedWith("Score too low to vouch");
    });
  });
});
